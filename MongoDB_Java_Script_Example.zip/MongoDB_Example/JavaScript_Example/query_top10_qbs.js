// MongoDB Shell Script: Query Top 10 Quarterbacks by Games Played
// 
// Usage: mongosh < query_top10_qbs.js
//
// This script assumes data has already been loaded into the 'sports_db.quarterbacks' collection

// Switch to the sports database
use sports_db

print("\n" + "=".repeat(80))
print("TOP 10 QUARTERBACKS BY GAMES PLAYED (G)")
print("=".repeat(80))

// Method 1: Simple find and manual sum
var top10 = db.quarterbacks.find().sort({G: -1}).limit(10).toArray()
var totalGames = 0

print("\nRank   Player                              Games   FPTS/G")
print("-".repeat(80))

top10.forEach(function(qb) {
    var playerStr = qb.Player.padEnd(35)
    var rankStr = String(qb.Rank).padStart(5)
    var gamesStr = String(qb.G).padStart(5)
    var fptsStr = qb["FPTS/G"].toFixed(1).padStart(6)
    
    print(rankStr + "  " + playerStr + " " + gamesStr + "   " + fptsStr)
    totalGames += qb.G
})

print("-".repeat(80))
print("TOTAL GAMES PLAYED BY TOP 10: " + totalGames)
print("=".repeat(80))

// Method 2: Using aggregation pipeline
print("\n" + "=".repeat(80))
print("USING AGGREGATION PIPELINE")
print("=".repeat(80))

var aggResult = db.quarterbacks.aggregate([
    { $sort: { G: -1 } },
    { $limit: 10 },
    { $group: {
        _id: null,
        total_games: { $sum: "$G" },
        avg_games: { $avg: "$G" },
        max_games: { $max: "$G" },
        min_games: { $min: "$G" },
        players: {
            $push: {
                rank: "$Rank",
                player: "$Player",
                games: "$G",
                fpts: "$FPTS",
                fpts_per_game: "$FPTS/G"
            }
        }
    }}
]).toArray()

if (aggResult.length > 0) {
    var stats = aggResult[0]
    
    print("\nStatistics for Top 10 QBs:")
    print("  Total Games:   " + stats.total_games)
    print("  Average Games: " + stats.avg_games.toFixed(2))
    print("  Max Games:     " + stats.max_games)
    print("  Min Games:     " + stats.min_games)
    
    print("\nDetailed Player List:")
    stats.players.forEach(function(p, index) {
        print("  " + (index + 1) + ". " + p.player + " - " + p.games + " games, " + 
              p.fpts_per_game.toFixed(1) + " FPTS/G")
    })
}

print("\n" + "=".repeat(80))
print("QUERY COMPLETE")
print("=".repeat(80))
